
def root():
    return 'This is root of api'